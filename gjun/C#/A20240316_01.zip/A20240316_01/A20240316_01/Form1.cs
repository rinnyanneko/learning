namespace A20240316_01
{
    public partial class FormMainForm : Form
    {
        public FormMainForm()
        {
            InitializeComponent();
        }
    }
}

namespace A20240316_02
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            labelTitle.Text = "�� �� �� ��";
            labelTitle.BorderStyle = BorderStyle.Fixed3D;
            labelTitle.BackColor = Color.LightGreen;
            labelTitle.ForeColor = Color.IndianRed;
            labelTitle.Font = new Font("�L�n������", 16, FontStyle.Bold | FontStyle.Underline);
        }
    }
}

﻿namespace A20240316_02
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelTitle = new Label();
            label1 = new Label();
            label2 = new Label();
            textBoxFullName = new TextBox();
            label3 = new Label();
            label4 = new Label();
            radioButtonGenderMale = new RadioButton();
            radioButtonGenderFemale = new RadioButton();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            radioButtonBloodTypeA = new RadioButton();
            radioButtonBloodTypeB = new RadioButton();
            radioButtonBloodTypeO = new RadioButton();
            radioButtonBloodTypeAB = new RadioButton();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            groupBox1 = new GroupBox();
            checkBoxInterest1 = new CheckBox();
            checkBoxInterest3 = new CheckBox();
            checkBoxInterest2 = new CheckBox();
            checkBoxInterest4 = new CheckBox();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            comboBoxBDY = new ComboBox();
            label17 = new Label();
            comboBoxBDM = new ComboBox();
            label18 = new Label();
            comboBoxBDD = new ComboBox();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            label22 = new Label();
            buttonOutput = new Button();
            label23 = new Label();
            labelOutput = new Label();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // labelTitle
            // 
            labelTitle.BorderStyle = BorderStyle.FixedSingle;
            labelTitle.Location = new Point(20, 19);
            labelTitle.Name = "labelTitle";
            labelTitle.Size = new Size(234, 41);
            labelTitle.TabIndex = 0;
            labelTitle.Text = "label1";
            labelTitle.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = Color.Red;
            label1.Location = new Point(195, 19);
            label1.Name = "label1";
            label1.Size = new Size(59, 15);
            label1.TabIndex = 1;
            label1.Text = "labelTitle";
            label1.Visible = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(20, 93);
            label2.Name = "label2";
            label2.Size = new Size(43, 15);
            label2.TabIndex = 2;
            label2.Text = "姓名：";
            // 
            // textBoxFullName
            // 
            textBoxFullName.Location = new Point(62, 90);
            textBoxFullName.MaxLength = 14;
            textBoxFullName.Name = "textBoxFullName";
            textBoxFullName.ScrollBars = ScrollBars.Vertical;
            textBoxFullName.Size = new Size(186, 23);
            textBoxFullName.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = Color.Red;
            label3.Location = new Point(96, 86);
            label3.Name = "label3";
            label3.Size = new Size(103, 15);
            label3.TabIndex = 1;
            label3.Text = "textBoxFullName";
            label3.Visible = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(20, 140);
            label4.Name = "label4";
            label4.Size = new Size(43, 15);
            label4.TabIndex = 4;
            label4.Text = "性別：";
            // 
            // radioButtonGenderMale
            // 
            radioButtonGenderMale.AutoSize = true;
            radioButtonGenderMale.Location = new Point(77, 138);
            radioButtonGenderMale.Name = "radioButtonGenderMale";
            radioButtonGenderMale.Size = new Size(49, 19);
            radioButtonGenderMale.TabIndex = 5;
            radioButtonGenderMale.Text = "男性";
            radioButtonGenderMale.UseVisualStyleBackColor = true;
            // 
            // radioButtonGenderFemale
            // 
            radioButtonGenderFemale.AutoSize = true;
            radioButtonGenderFemale.CheckAlign = ContentAlignment.MiddleRight;
            radioButtonGenderFemale.Checked = true;
            radioButtonGenderFemale.Location = new Point(181, 138);
            radioButtonGenderFemale.Name = "radioButtonGenderFemale";
            radioButtonGenderFemale.Size = new Size(49, 19);
            radioButtonGenderFemale.TabIndex = 6;
            radioButtonGenderFemale.TabStop = true;
            radioButtonGenderFemale.Text = "女性";
            radioButtonGenderFemale.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.ForeColor = Color.Red;
            label5.Location = new Point(20, 125);
            label5.Name = "label5";
            label5.Size = new Size(145, 15);
            label5.TabIndex = 1;
            label5.Text = "radioButtonGenderMale";
            label5.Visible = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.ForeColor = Color.Red;
            label6.Location = new Point(118, 154);
            label6.Name = "label6";
            label6.Size = new Size(157, 15);
            label6.TabIndex = 1;
            label6.Text = "radioButtonGenderFemale";
            label6.Visible = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(20, 326);
            label7.Name = "label7";
            label7.Size = new Size(43, 15);
            label7.TabIndex = 7;
            label7.Text = "興趣：";
            // 
            // radioButtonBloodTypeA
            // 
            radioButtonBloodTypeA.AutoSize = true;
            radioButtonBloodTypeA.Location = new Point(59, 30);
            radioButtonBloodTypeA.Name = "radioButtonBloodTypeA";
            radioButtonBloodTypeA.Size = new Size(45, 19);
            radioButtonBloodTypeA.TabIndex = 8;
            radioButtonBloodTypeA.Text = "A型";
            radioButtonBloodTypeA.UseVisualStyleBackColor = true;
            // 
            // radioButtonBloodTypeB
            // 
            radioButtonBloodTypeB.AutoSize = true;
            radioButtonBloodTypeB.Location = new Point(59, 72);
            radioButtonBloodTypeB.Name = "radioButtonBloodTypeB";
            radioButtonBloodTypeB.Size = new Size(44, 19);
            radioButtonBloodTypeB.TabIndex = 8;
            radioButtonBloodTypeB.Text = "B型";
            radioButtonBloodTypeB.UseVisualStyleBackColor = true;
            // 
            // radioButtonBloodTypeO
            // 
            radioButtonBloodTypeO.AutoSize = true;
            radioButtonBloodTypeO.Location = new Point(154, 30);
            radioButtonBloodTypeO.Name = "radioButtonBloodTypeO";
            radioButtonBloodTypeO.Size = new Size(47, 19);
            radioButtonBloodTypeO.TabIndex = 8;
            radioButtonBloodTypeO.Text = "O型";
            radioButtonBloodTypeO.UseVisualStyleBackColor = true;
            // 
            // radioButtonBloodTypeAB
            // 
            radioButtonBloodTypeAB.AutoSize = true;
            radioButtonBloodTypeAB.Checked = true;
            radioButtonBloodTypeAB.Location = new Point(154, 72);
            radioButtonBloodTypeAB.Name = "radioButtonBloodTypeAB";
            radioButtonBloodTypeAB.Size = new Size(52, 19);
            radioButtonBloodTypeAB.TabIndex = 8;
            radioButtonBloodTypeAB.TabStop = true;
            radioButtonBloodTypeAB.Text = "AB型";
            radioButtonBloodTypeAB.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.ForeColor = Color.Red;
            label8.Location = new Point(2, 17);
            label8.Name = "label8";
            label8.Size = new Size(144, 15);
            label8.TabIndex = 1;
            label8.Text = "radioButtonBloodTypeA";
            label8.Visible = false;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.ForeColor = Color.Red;
            label9.Location = new Point(94, 46);
            label9.Name = "label9";
            label9.Size = new Size(146, 15);
            label9.TabIndex = 1;
            label9.Text = "radioButtonBloodTypeO";
            label9.Visible = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.ForeColor = Color.Red;
            label10.Location = new Point(2, 60);
            label10.Name = "label10";
            label10.Size = new Size(143, 15);
            label10.TabIndex = 1;
            label10.Text = "radioButtonBloodTypeB";
            label10.Visible = false;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.ForeColor = Color.Red;
            label11.Location = new Point(94, 88);
            label11.Name = "label11";
            label11.Size = new Size(151, 15);
            label11.TabIndex = 1;
            label11.Text = "radioButtonBloodTypeAB";
            label11.Visible = false;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(radioButtonBloodTypeAB);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(radioButtonBloodTypeB);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(radioButtonBloodTypeO);
            groupBox1.Controls.Add(label11);
            groupBox1.Controls.Add(radioButtonBloodTypeA);
            groupBox1.Location = new Point(14, 185);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(249, 113);
            groupBox1.TabIndex = 9;
            groupBox1.TabStop = false;
            groupBox1.Text = "血型：";
            // 
            // checkBoxInterest1
            // 
            checkBoxInterest1.AutoSize = true;
            checkBoxInterest1.Location = new Point(55, 356);
            checkBoxInterest1.Name = "checkBoxInterest1";
            checkBoxInterest1.Size = new Size(62, 19);
            checkBoxInterest1.TabIndex = 10;
            checkBoxInterest1.Text = "看電影";
            checkBoxInterest1.UseVisualStyleBackColor = true;
            // 
            // checkBoxInterest3
            // 
            checkBoxInterest3.AutoSize = true;
            checkBoxInterest3.Location = new Point(55, 395);
            checkBoxInterest3.Name = "checkBoxInterest3";
            checkBoxInterest3.Size = new Size(50, 19);
            checkBoxInterest3.TabIndex = 11;
            checkBoxInterest3.Text = "逛街";
            checkBoxInterest3.UseVisualStyleBackColor = true;
            // 
            // checkBoxInterest2
            // 
            checkBoxInterest2.AutoSize = true;
            checkBoxInterest2.Location = new Point(155, 356);
            checkBoxInterest2.Name = "checkBoxInterest2";
            checkBoxInterest2.Size = new Size(50, 19);
            checkBoxInterest2.TabIndex = 10;
            checkBoxInterest2.Text = "旅行";
            checkBoxInterest2.UseVisualStyleBackColor = true;
            // 
            // checkBoxInterest4
            // 
            checkBoxInterest4.AutoSize = true;
            checkBoxInterest4.Location = new Point(155, 395);
            checkBoxInterest4.Name = "checkBoxInterest4";
            checkBoxInterest4.Size = new Size(74, 19);
            checkBoxInterest4.TabIndex = 11;
            checkBoxInterest4.Text = "高空彈跳";
            checkBoxInterest4.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.ForeColor = Color.Red;
            label12.Location = new Point(20, 344);
            label12.Name = "label12";
            label12.Size = new Size(108, 15);
            label12.TabIndex = 1;
            label12.Text = "checkBoxInterest1";
            label12.Visible = false;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.ForeColor = Color.Red;
            label13.Location = new Point(146, 344);
            label13.Name = "label13";
            label13.Size = new Size(108, 15);
            label13.TabIndex = 1;
            label13.Text = "checkBoxInterest2";
            label13.Visible = false;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.ForeColor = Color.Red;
            label14.Location = new Point(20, 383);
            label14.Name = "label14";
            label14.Size = new Size(108, 15);
            label14.TabIndex = 1;
            label14.Text = "checkBoxInterest3";
            label14.Visible = false;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.ForeColor = Color.Red;
            label15.Location = new Point(146, 383);
            label15.Name = "label15";
            label15.Size = new Size(108, 15);
            label15.TabIndex = 1;
            label15.Text = "checkBoxInterest4";
            label15.Visible = false;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(20, 444);
            label16.Name = "label16";
            label16.Size = new Size(67, 15);
            label16.TabIndex = 12;
            label16.Text = "出生日期：";
            // 
            // comboBoxBDY
            // 
            comboBoxBDY.FormattingEnabled = true;
            comboBoxBDY.Location = new Point(40, 472);
            comboBoxBDY.Name = "comboBoxBDY";
            comboBoxBDY.Size = new Size(54, 23);
            comboBoxBDY.TabIndex = 13;
            comboBoxBDY.Text = "2000";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(96, 475);
            label17.Name = "label17";
            label17.Size = new Size(19, 15);
            label17.TabIndex = 14;
            label17.Text = "年";
            // 
            // comboBoxBDM
            // 
            comboBoxBDM.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxBDM.FormattingEnabled = true;
            comboBoxBDM.Items.AddRange(new object[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" });
            comboBoxBDM.Location = new Point(117, 472);
            comboBoxBDM.Name = "comboBoxBDM";
            comboBoxBDM.Size = new Size(38, 23);
            comboBoxBDM.TabIndex = 13;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(157, 475);
            label18.Name = "label18";
            label18.Size = new Size(19, 15);
            label18.TabIndex = 14;
            label18.Text = "月";
            // 
            // comboBoxBDD
            // 
            comboBoxBDD.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxBDD.FormattingEnabled = true;
            comboBoxBDD.Location = new Point(178, 472);
            comboBoxBDD.Name = "comboBoxBDD";
            comboBoxBDD.Size = new Size(38, 23);
            comboBoxBDD.TabIndex = 13;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(218, 475);
            label19.Name = "label19";
            label19.Size = new Size(19, 15);
            label19.TabIndex = 14;
            label19.Text = "日";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.ForeColor = Color.Red;
            label20.Location = new Point(19, 459);
            label20.Name = "label20";
            label20.Size = new Size(92, 15);
            label20.TabIndex = 1;
            label20.Text = "comboBoxBDY";
            label20.Visible = false;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.ForeColor = Color.Red;
            label21.Location = new Point(91, 494);
            label21.Name = "label21";
            label21.Size = new Size(97, 15);
            label21.TabIndex = 1;
            label21.Text = "comboBoxBDM";
            label21.Visible = false;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.ForeColor = Color.Red;
            label22.Location = new Point(152, 459);
            label22.Name = "label22";
            label22.Size = new Size(94, 15);
            label22.TabIndex = 1;
            label22.Text = "comboBoxBDD";
            label22.Visible = false;
            // 
            // buttonOutput
            // 
            buttonOutput.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 136);
            buttonOutput.Location = new Point(22, 540);
            buttonOutput.Name = "buttonOutput";
            buttonOutput.Size = new Size(231, 42);
            buttonOutput.TabIndex = 15;
            buttonOutput.Text = "輸出個人基本資料";
            buttonOutput.UseVisualStyleBackColor = true;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.ForeColor = Color.Red;
            label23.Location = new Point(91, 530);
            label23.Name = "label23";
            label23.Size = new Size(85, 15);
            label23.TabIndex = 1;
            label23.Text = "buttonOutput";
            label23.Visible = false;
            // 
            // labelOutput
            // 
            labelOutput.BorderStyle = BorderStyle.FixedSingle;
            labelOutput.Location = new Point(22, 605);
            labelOutput.Name = "labelOutput";
            labelOutput.Size = new Size(231, 99);
            labelOutput.TabIndex = 16;
            labelOutput.Text = "labelOutput";
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(275, 725);
            ControlBox = false;
            Controls.Add(labelOutput);
            Controls.Add(label23);
            Controls.Add(buttonOutput);
            Controls.Add(label19);
            Controls.Add(label18);
            Controls.Add(label17);
            Controls.Add(comboBoxBDD);
            Controls.Add(comboBoxBDM);
            Controls.Add(comboBoxBDY);
            Controls.Add(label16);
            Controls.Add(checkBoxInterest4);
            Controls.Add(checkBoxInterest3);
            Controls.Add(checkBoxInterest2);
            Controls.Add(checkBoxInterest1);
            Controls.Add(label13);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label22);
            Controls.Add(label21);
            Controls.Add(label20);
            Controls.Add(label12);
            Controls.Add(groupBox1);
            Controls.Add(label7);
            Controls.Add(radioButtonGenderFemale);
            Controls.Add(radioButtonGenderMale);
            Controls.Add(label4);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(textBoxFullName);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(labelTitle);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "MainForm";
            Text = "個人基本資料表";
            Load += MainForm_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelTitle;
        private Label label1;
        private Label label2;
        private TextBox textBoxFullName;
        private Label label3;
        private Label label4;
        private RadioButton radioButtonGenderMale;
        private RadioButton radioButtonGenderFemale;
        private Label label5;
        private Label label6;
        private Label label7;
        private RadioButton radioButtonBloodTypeA;
        private RadioButton radioButtonBloodTypeB;
        private RadioButton radioButtonBloodTypeO;
        private RadioButton radioButtonBloodTypeAB;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private GroupBox groupBox1;
        private CheckBox checkBoxInterest1;
        private CheckBox checkBoxInterest3;
        private CheckBox checkBoxInterest2;
        private CheckBox checkBoxInterest4;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private ComboBox comboBoxBDY;
        private Label label17;
        private ComboBox comboBoxBDM;
        private Label label18;
        private ComboBox comboBoxBDD;
        private Label label19;
        private Label label20;
        private Label label21;
        private Label label22;
        private Button buttonOutput;
        private Label label23;
        private Label labelOutput;
    }
}
